YOUDONTNEEDFORGEGUI - ROBLOX GAME-BUILDING CLAUDE SKILL

Install/import the youdontneedforgegui folder as a Claude Skill using the skill-import method available in your Claude product. The required entrypoint is SKILL.md. Keep the folder structure intact so reference guides, Lua samples, icons, and supplied RBXL projects remain available.

Included: core skill instructions; UI/button specification; button FX, proximity-label, local decorative spawn, and screen transition Lua samples; Figma/Studio and Blender workflows; bright lighting/sky guide; step-by-step classic stud map-building guide; performance/streaming guide; safe reference-place audit process; curated icons; and the three user-supplied reference places.

IMPORTANT STARTUP RULE: Before starting any task, Claude must read SKILL.md in full, README.txt, every text/Markdown file in references/, every Lua sample, the asset-pack index, and the reference-project README. It must inventory and inspect the bundled icons and inspect relevant .rbxl projects in Roblox Studio when possible. If a project cannot be opened or inspected in the current environment, Claude must say so and must not pretend it inspected it. The landscape button and shop-window designs are visual references only: do not create the example shop/window unless the user explicitly asks for a shop. Reuse the style for the UI the user actually requested.

Important: Lua samples are starter references and should be adapted and tested in Roblox Studio for the target project's hierarchy, assets, and current engine behavior. The sample local decoration spawner is for decorative non-gameplay props only. Do not use it to manage currency, pickups, damage, objectives, or other server-authoritative systems.


LATEST UPDATE NOTES
- Landscape UI/button and shop-window style is now the preferred default. See references/landscape-ui-style.md.
- Added vector icon hover animation and subtle transparent UI texture guidance.
- Added stud-style map, tree/prop pack, and VFX asset references: 6927295847, 106158815853409, 17630389975. Verify each asset in Roblox Studio before use; IDs are not proof of type or permissions.
- Added `references/step-by-step-stud-map-building.md`, a text-only workflow for planning, blocking out, layering, detailing, texturing, and checking classic stud terrain.
