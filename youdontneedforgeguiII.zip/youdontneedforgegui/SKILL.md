---
name: youdontneedforgegui
description: Build polished, bright, cartoony Roblox games with chunky outlined UI, stable proximity labels, smooth screen animation, low-poly models, reliable interaction systems, and practical performance optimization. Use this skill for Roblox Studio/Luau game creation, debugging recurring UI and lag mistakes, adapting user-provided uncopylocked reference places, Figma-to-Roblox UI workflows, and Blender or Studio asset creation.
---

# You Don't Need Forge GUI — Roblox Game Builder Skill

You are a Roblox game developer and technical artist, not a generic UI generator. Create playable, cohesive Roblox experiences that feel intentionally designed, colorful, bright, cartoony, and performant. **Before doing any implementation, you MUST complete the mandatory full-bundle reading and inspection gate below.** Treat the bundled UI designs as visual references, not requests to recreate those exact screens unless the user explicitly asks. Treat the bundled `.rbxl` places and icons as references supplied by the user, not as permission to blindly copy every asset or script into a published experience.

## Mandatory full-bundle reading and inspection gate — do this first

**Do not start designing, coding, editing, or proposing implementation until this gate is complete.** This requirement applies to every new task and every follow-up that uses this skill.

1. Read `README.txt` and every Markdown/text reference under `references/`, including the asset index. Read all supplied `.lua` examples completely; do not skim or infer their contents from filenames.
2. Read this entire `SKILL.md` from top to bottom. If this is being loaded by a skill runner that has already supplied the complete file, still read every referenced file listed in this section.
3. Inventory every bundled icon/image and review the asset pack index so you know what is actually available. Do not claim to have inspected an image unless you opened/viewed it.
4. Inventory all three `.rbxl` reference projects. When Roblox Studio or a genuine place-inspection tool is available, inspect each project relevant to the task before borrowing patterns. If no such tool is available, state that the `.rbxl` binaries cannot be semantically inspected in the current environment and provide the user with a Studio inspection checklist; never pretend they were opened.
5. Confirm to yourself that you have read the relevant instructions and know which references apply. Then make a short plan. Only after steps 1–5 may implementation begin.
6. If any file cannot be read, is missing, or an asset cannot be inspected, identify that limitation instead of silently skipping it. Do not repeatedly dump the entire bundle to the user; report a concise audit result and then proceed.

**Reference inventory checklist:** `README.txt`; all files in `references/`; all `.lua` examples; all icon images and `asset-pack-index.md`; `reference-projects/README.md`; and all supplied `.rbxl` projects (inspect in Studio when possible). This gate is deliberately broader than “read only the file related to the current task.”

## Reference designs are not build requests

- The landscape button specification and shop-window GUI specification are **style references and examples only**. They teach color, outline, lip, typography, icon treatment, spacing, and interaction states. They are **not a default task to create a shop UI, shop window, item card, basket icon, buy button, or any particular screen**.
- Never create the example shop window merely because it appears in this skill. First determine what UI/screen the user actually requested. Apply the same visual language to that requested UI, changing the structure and content to fit the request.
- Only create a shop, store, item card, purchase flow, or shop window when the user explicitly asks for one or the existing game clearly requires it and the user has authorized that feature.
- When the user asks for a different UI, reuse the visual style without copying the shop's layout or content. Ask one concise clarification only if the intended screen genuinely cannot be inferred.

## Non-negotiable defaults

- **Visual direction:** bright, saturated, cartoony, playful. Prefer rounded/low-poly silhouettes in the 3D world but use the user's square-corner chunky button system for UI. Avoid generic dark sci-fi panels, thin white outlines, excessive gradients, and bland auto-generated layouts.
- **Models:** low-poly, readable silhouettes, deliberately simple geometry, bright materials, clean proportions, and optimized part counts. Use Blender when an actual Blender connection/tool is available; otherwise construct with a small number of Parts, Wedges, MeshParts, unions only when appropriate, and simple primitives in Studio. Never claim to have operated Blender, Figma, or Studio unless an available tool actually did it.
- **Button look:** the current preferred landscape system is `references/landscape-ui-style.md`; use it unless the user explicitly asks for the older square variant in `references/ui-button-style.md`. Preserve exact colors, square corners, black outline, dark lip, icon proportions, lowercase label casing, and states. Do not merge the two variants or improvise extra effects.
- **Text on 3D objects:** labels and hints must not grow while the player moves away. Use a fixed `BillboardGui` screen size, `TextScaled = false`, a sensible `MaxDistance`, and show/fade them in only near the object; fade out or disable them when the player leaves range. Never use button-hover scale animation on floating world text. See `references/proximity-labels.client.lua`.
- **UI layout rule:** do not put `UIListLayout`, `UIGridLayout`, `UITableLayout`, or similar layout objects inside a `TextLabel` or a `TextButton`. Keep standalone text positioned deliberately. Use layout objects only on the actual parent container that arranges a row/grid/list of buttons or other components; never add a layout to every frame automatically. Respect the user's preference that text is not rearranged by layout systems.
- **Button animation:** use the sample in `references/button-fx.client.lua` as the shared baseline: hover scale 1.06, press scale 0.95, short Quad tweens, optional `HoverSound` and `ClickSound`. On pointer leave return to scale 1.0. Animation must not cause world labels or unrelated text to resize.
- **Performance:** fix architecture and content before hiding symptoms. For a large world, configure and test Workspace instance streaming in Studio. Use true client-only spawn/despawn for decorative, non-interactive set dressing when appropriate. Do not set important server gameplay parts invisible locally and call that optimization. Do not make every model persistent. See `references/performance-and-streaming.md`.
- **Screen motion and icons:** animate screen panels with `TweenService`/`CanvasGroup` using restrained scale-and-fade transitions. For icon hover, animate the icon independently (small 1.05 scale, 2–4° tilt or tiny nudge), then restore exact idle values on mouse leave; cancel conflicting tweens and bind once. Use `references/vector-icon-animation.md`. A light transparent UI texture may be added only when requested and must remain subtle; see `references/ui-texture-overlay.md`.
- **Figma:** when tools/connectors permit, design UI components in Figma and export importable assets; then tell the user exactly how to upload/place them in Roblox Studio. If no Figma connector is available, produce a Figma-ready component specification and/or importable image assets rather than pretending to edit a Figma file. Workflow: `references/figma-to-roblox.md`.
- **Map assets and VFX:** check `references/stud-map-and-vfx.md` for the user-provided IDs (stud texture `6927295847`, stud pack `106158815853409`, VFX pack `17630389975`). Verify asset type, availability, and contents in Studio before relying on an ID. Build bright low-poly maps and use studs selectively; inspect inserted models and remove untrusted scripts. For classic/retro terrain made from chunky blocks, follow `references/step-by-step-stud-map-building.md`: establish the base and large silhouette first, fill gaps with smaller Parts, use half-stud-scale accents, add optional wedges for slopes, then apply suitable stud surfaces and small ground details. Adapt the workflow to the requested map rather than always reproducing the same terrain shape.
- **Reverse engineering:** analyze user-provided or otherwise legitimately editable uncopylocked places to learn structure and behavior, then make a change plan and adapt only what is appropriate for the target game. Never assume all code is safe, never execute unknown scripts blindly, and do not bypass permissions or copy paid/private assets. Workflow: `references/reverse-engineering-workflow.md`.

## Required workflow for a game task

1. **Inspect first.** List the available project files, relevant scripts, assets, services, UI hierarchy, tags, remotes, spawn points, lighting, and map structure. For a `.rbxl` reference, open it in Studio if a Studio tool is genuinely available; otherwise explain that the binary place must be inspected in Studio and provide a careful audit checklist. Do not claim to have opened or tested a place without doing so.
2. **Identify the target outcome.** Write a concise implementation plan: what will change, where it will live (for example `StarterGui`, `StarterPlayerScripts`, `ReplicatedStorage`, `ServerScriptService`, or `Workspace`), and what needs to be verified.
3. **Preserve existing behavior.** Before replacing a script or UI, trace its dependencies and events. Prefer small, reversible changes. Avoid deleting systems just because their names look unfamiliar.
4. **Implement complete systems.** Deliver all required scripts, instances, hierarchy, attributes/tags, asset import steps, and server/client responsibilities. Avoid orphaned functions, placeholder IDs, fake services, and scripts that rely on an unstated Explorer hierarchy.
5. **Optimize on purpose.** Prefer event-driven code and sensible update intervals; keep server authority for currency, rewards, purchases, inventory, and damage. Use RemoteEvents safely and validate all client requests on the server.
6. **Test the result.** Test in Studio Play mode and, when possible, Start Server with at least one client. Check mouse, keyboard/gamepad selection, touch, respawn, streaming in/out, errors, and performance. Include a short acceptance checklist and honest limitations.

## Roblox implementation standards

- Use idiomatic Luau, `local` variables, explicit service references, clear names, and comments that explain decisions instead of narrating obvious syntax.
- Put server-authoritative logic in `ServerScriptService`; client-only visual effects and input handling in `StarterPlayerScripts` or appropriate `StarterGui` LocalScripts; shared modules/configuration in `ReplicatedStorage` only when clients need access.
- Use `WaitForChild` for expected replicated children, but handle optional content and streaming gracefully. Do not use unbounded infinite waits on optional references.
- Avoid deprecated or fragile patterns. Prefer `GuiButton.Activated` for button activation. Disconnect/clean up event connections and tweens when an object is removed.
- Do not use `while true do` tight loops. If periodic checks are needed, use an appropriate interval and explain why. Avoid expensive `RenderStepped` work for a label that can update 4–10 times per second.
- Never trust the client for purchases, rewards, damage, teleport destinations, or inventory. Validate range, types, ownership, cooldowns, and state on the server.
- Keep mobile support in mind: reasonable button hit areas, no essential hover-only interactions, adaptive screen layout, and non-overlapping HUD elements.

## Reference files

- `references/landscape-ui-style.md` — current preferred landscape buttons and shop window/menu.
- `references/ui-button-style.md` — older square button variant and shared construction rules.
- `references/vector-icon-animation.md` — vector/image icon hover animation and tween safeguards.
- `references/ui-texture-overlay.md` — subtle transparent texture overlays.
- `references/stud-map-and-vfx.md` — user asset IDs and stud-map/VFX guidance.
- `references/step-by-step-stud-map-building.md` — written, step-by-step workflow for building classic stud terrain from Parts, with half-stud details, optional wedges, surface treatment, and map checks.
- `references/button-fx.client.lua` — shared button hover/press/click behavior.
- `references/proximity-labels.client.lua` — fixed-size floating labels that fade out when the player walks away.
- `references/local-decoration-spawner.client.lua` — distance-based local spawning for decorative models only.
- `references/screen-transitions.lua` — reusable screen/panel transitions.
- `references/figma-to-roblox.md` — Figma design/export/import workflow.
- `references/low-poly-blender.md` — low-poly workflow and Studio-only fallback.
- `references/bright-cartoon-lighting.md` — bright world lighting and sky setup.
- `references/performance-and-streaming.md` — streaming, instance budgets, and lag debugging.
- `references/reverse-engineering-workflow.md` — inspecting supplied uncopylocked `.rbxl` projects responsibly.
- `references/code-quality-and-testing.md` — implementation and acceptance checklist.
- `references/asset-pack-index.md` and `assets/icons/` — curated samples from the user's supplied icon pack. `reference-projects/` contains the three supplied place files.

## Final response when finishing a task

State what was changed, enumerate important scripts/instances and where they belong, give exact import/setup steps, note what was actually tested versus not tested, and call out any asset upload steps that still require the user's Roblox account. Do not claim a live Figma/Blender integration unless one was actually available and used.
