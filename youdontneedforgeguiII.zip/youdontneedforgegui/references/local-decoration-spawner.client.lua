-- Optional example for DECORATION ONLY; place in StarterPlayerScripts.
-- Setup in Studio:
-- 1. Add Folder ReplicatedStorage/ClientDecorationTemplates.
-- 2. Put small, anchored, non-interactive Models/Parts there. No scripts or gameplay logic.
-- 3. Place invisible anchored Parts at desired positions in Workspace and tag each
--    with CollectionService tag "LocalDecorationSpawner".
-- 4. Give each anchor a string attribute TemplateName matching a template name.
-- 5. Optional number attribute SpawnDistance overrides SPAWN_DISTANCE.
--
-- These clones are client-only visual set dressing. Never put pickups, collisions,
-- damage, rewards, prompts required for gameplay, or authoritative logic in these templates.
-- For normal world geometry, prefer Workspace.StreamingEnabled instead.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")

local player = Players.LocalPlayer
local TAG = "LocalDecorationSpawner"
local DEFAULT_SPAWN_DISTANCE = 150
local DESPAWN_MULTIPLIER = 1.2
local CHECK_INTERVAL = 0.5

local templates = ReplicatedStorage:WaitForChild("ClientDecorationTemplates")
local spawned = {} -- [anchor] = clone

local function getRoot(): BasePart?
    local character = player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    if root and root:IsA("BasePart") then
        return root
    end
    return nil
end

local function setAtAnchor(clone: Instance, anchor: BasePart)
    if clone:IsA("Model") then
        clone:PivotTo(anchor.CFrame)
    elseif clone:IsA("BasePart") then
        clone.CFrame = anchor.CFrame
    end
end

local function removeClone(anchor: Instance)
    local clone = spawned[anchor]
    if clone then
        clone:Destroy()
        spawned[anchor] = nil
    end
end

local function ensureSpawned(anchor: Instance)
    if not anchor:IsA("BasePart") or not anchor:IsDescendantOf(workspace) then
        return
    end
    local templateName = anchor:GetAttribute("TemplateName")
    if typeof(templateName) ~= "string" or templateName == "" then
        return
    end
    local template = templates:FindFirstChild(templateName)
    if not template or not (template:IsA("Model") or template:IsA("BasePart")) then
        return
    end
    local clone = template:Clone()
    clone.Name = template.Name .. "_LocalDecoration"

    -- Enforce that this system only creates anchored, non-interactive decoration.
    for _, descendant in ipairs(clone:GetDescendants()) do
        if descendant:IsA("Script") or descendant:IsA("LocalScript") or descendant:IsA("ModuleScript") then
            descendant:Destroy()
        elseif descendant:IsA("BasePart") then
            descendant.Anchored = true
            descendant.CanCollide = false
            descendant.CanTouch = false
            descendant.CanQuery = false
        end
    end
    if clone:IsA("BasePart") then
        clone.Anchored = true
        clone.CanCollide = false
        clone.CanTouch = false
        clone.CanQuery = false
    end

    setAtAnchor(clone, anchor)
    clone.Parent = workspace
    spawned[anchor] = clone
end

while true do
    task.wait(CHECK_INTERVAL)
    local root = getRoot()
    if root then
        for _, anchor in ipairs(CollectionService:GetTagged(TAG)) do
            if anchor:IsA("BasePart") and anchor:IsDescendantOf(workspace) then
                local distance = (root.Position - anchor.Position).Magnitude
                local radius = anchor:GetAttribute("SpawnDistance")
                if typeof(radius) ~= "number" or radius <= 0 then
                    radius = DEFAULT_SPAWN_DISTANCE
                end
                if not spawned[anchor] and distance <= radius then
                    ensureSpawned(anchor)
                elseif spawned[anchor] and distance > radius * DESPAWN_MULTIPLIER then
                    removeClone(anchor)
                end
            else
                removeClone(anchor)
            end
        end
        -- Clear any tracked anchor that was removed/streamed out.
        for anchor in pairs(spawned) do
            if not anchor.Parent then
                removeClone(anchor)
            end
        end
    end
end
