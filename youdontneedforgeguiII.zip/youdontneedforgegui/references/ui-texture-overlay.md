# Subtle transparency / texture overlay for UI

The default landscape UI is clean and flat. When the user asks for a bit of transparent texture, add only a restrained overlay that does not fight the black outline, gradient, label, or icon.

- Use a transparent tile/noise pattern or a few sparse speckles at low opacity (typically visual transparency 0.88–0.95, adjusted by inspection). Keep it clipped to the panel/face so it never spills outside the square outline.
- Use `ImageLabel.BackgroundTransparency = 1`, a valid uploaded `Image` asset, `ScaleType = Tile` for repeatable texture where appropriate, and a conservative `ImageTransparency`. Roblox's `ImageTransparency` is 0 opaque and 1 invisible; remember the direction.
- If the texture is authored in Figma, export a transparent PNG layer and import it as an image asset. Do not invent asset IDs. For a lightweight UI, reuse one small seamless texture asset instead of creating many unique large images.
- Texture should be barely noticeable at normal size. Never obscure text stroke, icon silhouette, button lip, or outline. Do not add texture to the text itself unless explicitly requested.
- Do not use per-frame random noise or continuously changing textures. Static overlays have negligible animation cost. If no suitable texture asset exists, use a very subtle static pattern created in Figma or skip it rather than adding a distracting placeholder.
- Keep the no-shadow/no-glow rule. A transparent texture is not permission to add glassmorphism, bloom, rounded corners, or glossy gradients beyond the specified icon shading.
