# Stud-style maps, trees, and VFX asset references

User-provided Roblox asset IDs:
- Stud texture / map surface reference: `6927295847`
- Stud pack / tree or environment prop reference: `106158815853409`
- VFX pack reference: `17630389975`

These are reference IDs only. Before relying on them, open the assets in Roblox Studio/Creator Marketplace and confirm they still exist, their type, permissions, ownership, and whether they are models, images, packages, or effects. Do not assume an ID is a texture just because the user described it that way; Roblox asset IDs can point to different asset classes. Do not claim an asset has been imported or is available in the project until verified.

## Map construction direction
- Make a bright, cartoony low-poly environment. Use the stud asset where it visually helps—e.g. ground, platforms, trim, or selected build pieces—not indiscriminately on every surface if that makes the map visually noisy.
- Use the supplied stud pack as a starting point for tree/foliage/environment props if its contents match. Inspect the model before using it; remove unused scripts and unnecessary parts, check collisions/anchoring, simplify meshes where practical, and confirm no unwanted scripts or remote behavior.
- Trees should use a readable low-poly silhouette, simple trunk, and a small number of stylized foliage pieces. Vary scale/rotation slightly by design rather than placing identical copies in a rigid grid. Group reusable props into models and use sensible collision settings.
- Organize large maps into regions/chunks and use Roblox instance streaming and client-only spawning for decorative objects when appropriate. Important gameplay geometry, pickups, hazards, and interactables must not be made client-only if all players need to interact with them.

## VFX use
- Inspect the VFX pack and identify the exact effect types before integration. Use effects sparingly to reinforce important actions: purchase success, reward, teleport, collectible pickup, button confirmation, or environmental ambience.
- Respect performance: limit simultaneous emitters/particles, lifetimes, rates, and light sources; clean up temporary effects with Debris or explicit lifecycle code. Avoid emitting large particle bursts continuously at every object.
- Server-authoritative events should trigger replicated gameplay effects only where necessary. Purely cosmetic effects can often run on the client. Validate purchases/rewards on the server; VFX must never be treated as proof that a transaction succeeded.
- Test at low graphics settings and on mobile. If the asset IDs are unavailable or inappropriate, ask for the actual model/texture files or have the user insert the assets in Studio and report their verified hierarchy.
