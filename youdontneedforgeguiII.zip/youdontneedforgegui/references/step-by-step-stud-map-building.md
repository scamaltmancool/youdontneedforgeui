# Step-by-step classic stud map construction

Use this workflow when the user asks for a classic/retro Roblox map built from chunky Parts, especially layered grass, hills, islands, rocky platforms, or small showcase terrain. Adapt the theme, footprint, colors, and silhouette to the user's brief; the example sequence is a building method, not a requirement to make every map into the same green mound.

## 1. Plan the silhouette and create a base

1. Decide what the terrain should read as from the player's normal camera view: a hill, island, cliff, platform, garden patch, path, or another clear shape.
2. Choose a footprint large enough for the terrain and any required player movement. Start with one simple rectangular Roblox `Part` as the base/platform. Set its size, position, material, and color to fit the theme; for a grassy classic look, use a grass-green palette.
3. Anchor the base. Keep it simple at this stage. It is a guide for the build's overall bounds, not the finished terrain.
4. Before adding details, establish the main direction of the terrain and where its highest and lowest areas should be.

## 2. Block out the main terrain with large Parts

1. Use ordinary Roblox `Part` blocks to create the largest masses first. Place several large blocks on the base and stack or overlap them into a rough stepped silhouette.
2. Vary block width, depth, and height so the shape has a clear high area, lower shelves, and an irregular outline. Use offsets and different lengths rather than arranging every block in a perfect grid.
3. Build the silhouette in broad layers. Make sure the major forms read clearly before adding small pieces; do not start by decorating every surface.
4. Position the blocks so seams and gaps are intentional. Where blocks intersect, ensure they do not create distracting exposed slivers or impossible collision shapes.

## 3. Fill empty gaps with medium and small blocks

1. Once the main shape feels right, inspect the empty spaces between its larger blocks.
2. Add smaller ordinary Parts in those gaps to connect the forms, create stepped transitions, and make the terrain feel layered instead of like a few disconnected cubes.
3. Add more pieces gradually, checking the silhouette from the front, sides, and the expected player camera. Keep some broad surfaces visible so the build does not turn into visual noise.
4. Use clusters and uneven spacing. Repeating the same size and exact spacing everywhere makes a terrain piece look mechanical.

## 4. Mix standard and half-stud-scale details

1. Use regular block sizes for the primary shape and smaller pieces around the edges and between layers.
2. The tutorial demonstrates 0.5-stud-scale blocks alongside 1-by-1-stud-scale blocks. Use the smaller scale for fine ledges, little stones, tiny steps, and other small terrain accents.
3. Keep small pieces subordinate to the large forms. Concentrate them around transitions, along a few edges, or in small clusters rather than covering every surface equally.
4. Keep the pieces aligned enough to feel intentional, but vary their placement and dimensions where that improves the silhouette.

## 5. Optionally add WedgeParts for angled transitions

1. If the shape needs slopes, ramps, or angled sides, add Roblox `WedgePart` instances from Studio's part-insertion controls.
2. Rotate and position each wedge so it connects naturally to the surrounding blocks. Match its material and color to the terrain.
3. Use wedges selectively to break up an otherwise box-only silhouette. They are optional; a fully blocky map can remain blocky if that suits the requested style.
4. Check that the wedge does not float, leave an obvious gap, or create an awkward collision edge.

## 6. Apply a classic stud surface treatment

1. For a classic/retro build, add stud-style surfaces to appropriate exposed faces, especially top surfaces that should read as classic Roblox construction. Use the treatment consistently enough to feel like one style, but avoid adding texture where it makes the map hard to read.
2. The video shows a Studio plugin named **“Resurface - Convert surfaces to studs and more”** as a convenient way to access classic surface styles. Treat the plugin as a tool the creator used, not as a guaranteed dependency: verify that it is available and appropriate in the user's Studio environment before relying on it.
3. If the plugin is unavailable, continue with a suitable verified Studio workflow for the desired stud texture/surface; do not pretend that the plugin is installed or has been run.
4. Inspect the result from normal gameplay distance. Stud detailing should support the retro look without making the whole terrain visually busy.

## 7. Add small ground details and refine the composition

1. Add a final pass of tiny block-based details, such as pebble-like clusters, little raised chips, or small accents around the foot of the terrain and in selected gaps. Half-stud-scale pieces work well for this.
2. Place details to guide the eye through the terrain and reinforce its shape. Vary cluster size and spacing; avoid a uniform scatter pattern.
3. Leave clear paths and usable footing wherever players need to walk. Keep decorative details out of important movement routes unless the design intentionally makes them obstacles.
4. Compare the build at close and normal gameplay distances. Remove pieces that look accidental, float, clip awkwardly, or add clutter without improving the silhouette.

## 8. Organize and verify the finished map

1. Put related terrain pieces in sensibly named `Model` instances or folders under a clear map hierarchy, such as `Workspace/Map/Terrain` and `Workspace/Map/Details`.
2. Anchor static terrain. Set collisions according to purpose: main ground and walkable platforms should support the player, while nonessential decoration should not block movement unless intended.
3. Check for gaps, overlaps, floating details, inconsistent colors/materials, and unsafe or excessive part counts. Keep repeated pieces organized and reuse simple shapes where practical.
4. Test in Studio Play mode and walk around the map. Verify that the shape is readable, the player can reach intended areas, and collision behaves as expected.
5. If you cannot directly create or inspect the place in Studio, provide a complete, runnable Luau build script or a precise instance hierarchy and say what must be tested in Studio. Do not claim that the map was tested when it was not.

## Key principles

- Build large forms first, then fill gaps, then add fine details.
- Use ordinary Parts as the foundation of this workflow; use 0.5-stud-scale pieces and WedgeParts selectively.
- Classic stud texture is a style choice for retro builds, not a mandatory treatment for every genre.
- Prioritize a readable silhouette, purposeful layering, walkability, anchoring, and clean collisions over sheer part count.
