-- Place as a LocalScript in StarterPlayerScripts.
-- Buttons must be descendants of a ScreenGui in PlayerGui.
-- This controller animates UI buttons only. Never bind it to BillboardGui world labels.

local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")
local SoundService = game:GetService("SoundService")
local UserInputService = game:GetService("UserInputService")

local playerGui = Players.LocalPlayer:WaitForChild("PlayerGui")
local hoverSound = SoundService:FindFirstChild("HoverSound")
local clickSound = SoundService:FindFirstChild("ClickSound")

local HOVER_SCALE = 1.06
local PRESS_SCALE = 0.95
local BOUND_ATTR = "ButtonFX_Bound"
local HOVER_INFO = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local PRESS_INFO = TweenInfo.new(0.08, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)

local function bind(btn: GuiButton)
    if btn:GetAttribute(BOUND_ATTR) then
        return
    end
    btn:SetAttribute(BOUND_ATTR, true)
    btn.AutoButtonColor = false

    local scale = btn:FindFirstChildOfClass("UIScale")
    if not scale then
        scale = Instance.new("UIScale")
        scale.Scale = 1
        scale.Parent = btn
    end

    local hovered = false
    local pressed = false
    local activeTween: Tween? = nil

    local function tweenTo(value: number, info: TweenInfo)
        if activeTween then
            activeTween:Cancel()
            activeTween = nil
        end
        activeTween = TweenService:Create(scale, info, { Scale = value })
        activeTween:Play()
    end

    local function updateScale()
        if pressed then
            tweenTo(PRESS_SCALE, PRESS_INFO)
        elseif hovered then
            tweenTo(HOVER_SCALE, HOVER_INFO)
        else
            tweenTo(1, HOVER_INFO)
        end
    end

    btn.MouseEnter:Connect(function()
        hovered = true
        if hoverSound and hoverSound:IsA("Sound") then
            hoverSound:Play()
        end
        updateScale()
    end)

    btn.MouseLeave:Connect(function()
        hovered = false
        pressed = false -- Do not leave a button stuck at 0.95 when the pointer exits mid-press.
        updateScale() -- Reset to 1.0 as soon as the pointer leaves.
    end)

    btn.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
            or input.UserInputType == Enum.UserInputType.Touch then
            pressed = true
            updateScale()
        end
    end)

    btn.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
            or input.UserInputType == Enum.UserInputType.Touch then
            pressed = false
            updateScale()
        end
    end)

    btn.SelectionGained:Connect(function()
        hovered = true
        updateScale()
    end)

    btn.SelectionLost:Connect(function()
        hovered = false
        pressed = false
        updateScale()
    end)

    btn.Activated:Connect(function()
        if clickSound and clickSound:IsA("Sound") then
            clickSound:Play()
        end
    end)

    btn.Destroying:Connect(function()
        if activeTween then
            activeTween:Cancel()
        end
    end)
end

local function scan(root: Instance)
    for _, item in ipairs(root:GetDescendants()) do
        if item:IsA("TextButton") or item:IsA("ImageButton") then
            bind(item)
        end
    end
    root.DescendantAdded:Connect(function(item)
        if item:IsA("TextButton") or item:IsA("ImageButton") then
            bind(item)
        end
    end)
end

for _, child in ipairs(playerGui:GetChildren()) do
    if child:IsA("ScreenGui") then
        scan(child)
    end
end

playerGui.ChildAdded:Connect(function(child)
    if child:IsA("ScreenGui") then
        scan(child)
    end
end)

-- Expected optional sounds in SoundService: HoverSound and ClickSound.
-- The script still works when either sound is absent. Set each sound's SoundId in Studio.
