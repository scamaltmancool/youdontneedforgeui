-- Place as a LocalScript in StarterPlayerScripts.
-- Tag a BasePart or Model with CollectionService tag "NearLabel".
-- Optional instance attribute: NearLabelText (string). Models should have a PrimaryPart.
-- The label is fixed-size, fades in near the player, and fades out when leaving range.
-- This is a world-label system; do not run the button UIScale animation on these labels.

local Players = game:GetService("Players")
local CollectionService = game:GetService("CollectionService")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")
local TAG = "NearLabel"
local SHOW_DISTANCE = 24
local HIDE_DISTANCE = 29 -- Hysteresis prevents flicker around the boundary.
local CHECK_INTERVAL = 0.15

local records = {}
local FADE_IN = TweenInfo.new(0.14, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
local FADE_OUT = TweenInfo.new(0.12, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

local function getAdornee(instance: Instance): BasePart?
    if instance:IsA("BasePart") then
        return instance
    end
    if instance:IsA("Model") then
        if instance.PrimaryPart then
            return instance.PrimaryPart
        end
        return instance:FindFirstChildWhichIsA("BasePart", true)
    end
    return nil
end

local function setVisible(record, visible: boolean)
    if record.visible == visible then
        return
    end
    record.visible = visible

    if record.tween then
        record.tween:Cancel()
        record.tween = nil
    end

    local targetText = visible and 0 or 1
    local targetStroke = visible and 0.12 or 1
    if visible then
        record.gui.Enabled = true
    end

    local info = visible and FADE_IN or FADE_OUT
    record.tween = TweenService:Create(record.label, info, {
        TextTransparency = targetText,
        TextStrokeTransparency = targetStroke,
    })
    record.tween:Play()

    if not visible then
        local thisTween = record.tween
        thisTween.Completed:Once(function()
            if record.gui and record.gui.Parent and not record.visible then
                record.gui.Enabled = false
            end
        end)
    end
end

local function addTarget(instance: Instance)
    if records[instance] then
        return
    end
    local adornee = getAdornee(instance)
    if not adornee then
        return
    end

    local gui = Instance.new("BillboardGui")
    gui.Name = "LocalNearLabel"
    gui.Adornee = adornee
    gui.Size = UDim2.fromOffset(190, 42) -- Fixed screen-pixel canvas: don't use a distance-growing scale.
    gui.StudsOffsetWorldSpace = Vector3.new(0, 2.7, 0)
    gui.MaxDistance = HIDE_DISTANCE + 2
    gui.AlwaysOnTop = false
    gui.LightInfluence = 0
    gui.Enabled = false
    gui.Parent = playerGui

    local label = Instance.new("TextLabel")
    label.Name = "Label"
    label.BackgroundTransparency = 1
    label.BorderSizePixel = 0
    label.Size = UDim2.fromScale(1, 1)
    label.Position = UDim2.fromScale(0, 0)
    label.Font = Enum.Font.GothamBold
    label.Text = tostring(instance:GetAttribute("NearLabelText") or instance.Name)
    label.TextSize = 20 -- Fixed font size; do not set TextScaled = true.
    label.TextScaled = false
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
    label.TextStrokeTransparency = 1
    label.TextTransparency = 1
    label.TextWrapped = true
    label.Parent = gui

    records[instance] = {
        gui = gui,
        label = label,
        adornee = adornee,
        visible = false,
        tween = nil,
    }
end

local function removeTarget(instance: Instance)
    local record = records[instance]
    if not record then
        return
    end
    if record.tween then
        record.tween:Cancel()
    end
    if record.gui then
        record.gui:Destroy()
    end
    records[instance] = nil
end

for _, instance in ipairs(CollectionService:GetTagged(TAG)) do
    addTarget(instance)
end
CollectionService:GetInstanceAddedSignal(TAG):Connect(addTarget)
CollectionService:GetInstanceRemovedSignal(TAG):Connect(removeTarget)

while true do
    task.wait(CHECK_INTERVAL)
    local character = player.Character
    local root = character and character:FindFirstChild("HumanoidRootPart")
    if root and root:IsA("BasePart") then
        for instance, record in pairs(records) do
            if not instance:IsDescendantOf(workspace) or not record.adornee:IsDescendantOf(workspace) then
                removeTarget(instance) -- Cleanup when an instance streams out or is removed.
            else
                local distance = (root.Position - record.adornee.Position).Magnitude
                if record.visible then
                    setVisible(record, distance <= HIDE_DISTANCE)
                else
                    setVisible(record, distance <= SHOW_DISTANCE)
                end
            end
        end
    else
        for instance, record in pairs(records) do
            if record.visible then
                setVisible(record, false)
            end
        end
    end
end
