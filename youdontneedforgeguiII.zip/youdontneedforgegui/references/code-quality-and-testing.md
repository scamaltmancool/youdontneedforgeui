# Code quality and test checklist

## Implementation

- Keep server and client responsibilities explicit.
- Use `Activated` for button click behavior; use hover events only for pointer-specific decoration.
- Use fixed-position native TextLabels for in-world labels. They should fade/disappear after the player leaves range, not grow when walking away.
- Create one shared button FX controller rather than copy-pasting different hover scripts onto each button.
- Avoid duplicate event binding using a marker attribute or connection registry.
- Cancel prior tweens before starting replacements; clean up on `Destroying` or when tagged objects stream out.
- Guard optional sounds/assets and never use placeholder IDs as if they were valid.
- Keep the UI hierarchy consistent and readable in Explorer.
- Only add layouts to explicit collection containers; do not parent layout instances under text objects.
- For RemoteEvents/RemoteFunctions, validate arguments and state on the server. A client request is not proof that the player owns an item or earned a reward.

## Functional tests

- Game starts without errors or infinite yields.
- Player spawns, respawns, dies, and reconnects without stale UI or connections.
- Store/settings/play/reward buttons open the correct panels once, play optional sounds, and never get stuck at 0.95 or 1.06 scale.
- Mouse enter brightens/scales only the button group; mouse leave returns it to normal size.
- Mouse click, touch, keyboard/gamepad selection, and activation are tested.
- Disabled buttons do not execute actions and have a readable desaturated state.
- World labels stay a fixed screen size, appear only near their object, and fade/disappear when leaving range.
- Screen panels animate in/out without flicker, stuck transparency, or overlapping tweens.
- Decorative models spawn near and clean up far; they contain no gameplay scripts or interactive responsibilities.
- Streaming tests include running away from the spawn, returning, teleporting, and respawning.
- Currency, inventory, purchases, damage, and rewards are validated server-side.

## Visual tests

- Button corners remain square; outline thickness and lip proportions are consistent.
- White text has a thick black outline; text and icon stay readable at small sizes.
- No text clipping, blurry icons, accidental white PNG backgrounds, or invented asset IDs.
- World palette is bright and cartoony; the sky does not wash out all colors.
- The main path is readable and interactive objects have enough visual contrast.
- HUD and panels fit desktop and small/mobile aspect ratios.

## Performance tests

- Compare the same route before and after changes.
- Use Studio diagnostics to identify the real bottleneck.
- Check instance count, expensive lights/effects, unanchored decorations, constraints, script loops, and remote traffic.
- Do not call visual transparency a performance optimization if the instance is still being rendered/replicated.
- Report only the tests actually performed and clearly disclose anything that still needs opening/testing in Studio.
