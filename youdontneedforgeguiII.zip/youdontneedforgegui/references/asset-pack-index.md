# Supplied icon references

`assets/icons/` contains a curated subset from the user's uploaded `Free Icon Pack v3.1 (Basic).zip`. The original archive contains far more files than a small Claude Skill package can safely carry under common per-ZIP file-count limits, so this skill bundles selected 256px examples useful for game UIs: shopping/cart, settings, rewards, inventory, currency, pets, player, and common UI states.

The PNG filenames are normalized to lowercase ASCII with hyphens to avoid ZIP extraction problems. They are visual references and import candidates, not pre-uploaded Roblox asset IDs. To use them in a live game, import the relevant PNG through Roblox Studio and use the image ID Roblox assigns. Check the original pack's license/attribution terms before publishing or redistributing its images. Do not invent asset IDs or claim ownership of third-party art.

The three `.rbxl` projects in `reference-projects/` were supplied by the user. See the audit procedure in `reverse-engineering-workflow.md` before running scripts or moving assets between places.


## Additional user-provided Roblox asset IDs
See `stud-map-and-vfx.md` for the stud texture/map reference `6927295847`, stud/tree pack `106158815853409`, and VFX pack `17630389975`. Verify availability and actual asset type in Studio before use.
