# Bright cartoony Lighting and Sky

Treat these as a starting look, then test outdoors, indoors, under UI overlays, and on low-end devices. A bright world does not require excessive bloom or washed-out white surfaces.

## Starting setup in Studio

- `Lighting.ClockTime`: start around 13.5–14.5 for a warm daytime mood.
- `Lighting.Brightness`: start around 2 and adjust after testing the map.
- `Lighting.ExposureCompensation`: begin near 0, then tune in small increments. Avoid hiding bad material choices with huge exposure values.
- `Lighting.Ambient` and `OutdoorAmbient`: use soft, slightly cool/warm tints instead of pure black shadows.
- `Lighting.EnvironmentDiffuseScale` and `EnvironmentSpecularScale`: keep reasonable so shiny toy-like materials read without turning everything metallic.
- Add a restrained `Atmosphere` if needed for depth; keep density and haze low for a clean, bright world.
- Use one valid `Sky` asset or a sky asset the user owns/has permission to use. Do not invent Skybox asset IDs.
- Use `ColorCorrectionEffect` sparingly. Strong saturation/contrast filters can make text hard to read and turn bright surfaces into glare.
- `BloomEffect` is optional and should be subtle. The primary style comes from color, models, materials, and light placement, not post-processing spam.

Some Lighting properties/settings are Studio-configured rather than something a LocalScript should set. Make non-scriptable property changes in the Studio Properties panel and note that explicitly.

## Directional styling

- Use a clear key light with readable shadows and a consistent daylight direction.
- Use accent lights only for points of interest. Lots of real-time lights and shadows can hurt performance.
- Keep UI contrast separate from world lighting. `BillboardGui` labels should stay readable and fixed-size rather than growing/shrinking with camera distance.
- Prefer `SmoothPlastic`, `Plastic`, and intentional color choices for toy-like props; use reflective/metallic materials only where they clarify the object's purpose.
- Make sky, terrain, map palette, and UI palette feel like the same game. Bright cartoony does not mean every surface must use a different neon color.

## Validate

Test noon-like outdoor lighting, interiors, shaded corners, respawn locations, and far-distance visibility. Check that important silhouettes do not blend into the sky and that the camera does not face a white-out background. For low-end target devices, reduce the number of shadow-casting lights and expensive post effects first.
