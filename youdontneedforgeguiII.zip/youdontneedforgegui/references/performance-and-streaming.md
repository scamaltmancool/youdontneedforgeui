# Performance, streaming, and distance-based content

First identify the lag source. Do not assume every stutter is caused by visible object count: it may be physics, too many connections/tweens, high-poly meshes, textures, remote traffic, particles, scripts, or excessive GUI updates.

## World streaming

For a large map, open `Workspace` in Studio and review `StreamingEnabled` and related streaming properties. `Workspace.StreamingEnabled` is configured in Studio and cannot be set from a normal game script. Use built-in instance streaming for ordinary world regions rather than writing a custom system that hides every Part. Choose `ModelStreamingMode` deliberately. `Persistent` models never stream out and should be rare; making everything persistent defeats the goal.

Set up streaming first, then test teleportation, respawn, vehicles, NPCs, camera focus, and client scripts that access streamed instances. Client code must tolerate missing/streamed-out instances. Do not assume a model's descendants exist just because its parent exists. Consult the official docs linked below for exact current engine behavior.

## Objects appear near, disappear far

Use the right strategy for the object type:

- **Ordinary map buildings and terrain:** built-in `Workspace` streaming and sensible model organization.
- **Floating labels and prompts:** `BillboardGui.MaxDistance`, fixed `Size = UDim2.fromOffset(...)`, and a proximity fade. `references/proximity-labels.client.lua` is a starting example.
- **Purely decorative distant details:** optionally store templates in `ReplicatedStorage/ClientDecorationTemplates` and spawn client-only clones from tagged anchors near the player. `references/local-decoration-spawner.client.lua` documents the setup.
- **Gameplay objects:** keep server authority. Use ProximityPrompt or validated server-side interaction; do not locally destroy or hide a real pickup, hazard, NPC, or objective as a substitute for implementing correct state.

The local-decoration example is not a general-purpose map streamer. It is only for anchored, non-interactive visual dressing. In Studio, test streamed anchors and clone cleanup. For very large worlds, use Roblox instance streaming instead of one local spawner per tiny object.

## Common high-impact optimizations

- Remove redundant loops; prefer events, tags, and amortized checks over one `RenderStepped` loop per object.
- Avoid creating a new tween every frame or leaving tweens/event connections running after UI is removed.
- Anchor static decorations and simplify collision. Reduce unnecessary parts, joints, constraints, particles, and shadow-casting lights.
- Reuse templates with `Clone()` where appropriate, but don't clone enormous models when a few parts work.
- Keep replicated data lean. Don't broadcast cosmetic-only updates to every client unless needed.
- Make server validation authoritative and avoid remote-event spam.
- Use Studio's MicroProfiler, Script Performance, and client/server tests to measure before/after. Do not claim a speed-up without a measured comparison.

## Debug checklist

1. Is the frame drop GPU/render (too many objects, effects, shadows) or CPU/script/physics (loops, constraints, remotes)?
2. Does it happen on spawn, teleport, streaming, an animation, or continuously?
3. Which exact area or system is expensive?
4. Can the same look be achieved with fewer instances and simpler collision?
5. Are objects truly streamed/destroyed when irrelevant, rather than merely set transparent?
6. Is client code safe when an instance streams out and comes back?
7. Did performance improve after the change on a repeatable test route?

## Official reading

- Instance streaming: https://create.roblox.com/docs/workspace/streaming
- Streaming techniques: https://create.roblox.com/docs/workspace/streaming/techniques
- Model streaming properties: https://create.roblox.com/docs/reference/engine/classes/Model
- BillboardGui: https://create.roblox.com/docs/reference/engine/classes/BillboardGui
- TweenService: https://create.roblox.com/docs/reference/engine/classes/TweenService
