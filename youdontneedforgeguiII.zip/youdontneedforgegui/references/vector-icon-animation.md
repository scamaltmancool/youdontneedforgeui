# Vector-style icon animation and hover feedback

Goal: give the UI icons a little personality without making the UI noisy. Animate icon art separately from the button's label and outline when practical.

## Preferred workflow
- In Figma, keep each icon as a separate vector component/layer with a clean silhouette and consistent black sticker outline. Export SVG only if the chosen Roblox pipeline supports it reliably; otherwise export transparent PNG at 2× or 3× target size. Roblox UI normally uses imported image assets, so do not assume arbitrary SVG can be assigned directly to an ImageLabel.
- Keep the outline, highlight/shading, and main silhouette grouped so they animate as one icon. If individual pieces need motion, separate them intentionally (e.g. basket body, handle, shine) and anchor pivots sensibly.
- In Roblox, put the icon in an `ImageLabel` or `ImageButton` under a button. Add a `UIScale` or tween `Size`/`Rotation` for hover, using `TweenService`. Avoid changing the text size as a side effect.
- Hover animation target: icon scales from 1.0 to about 1.05, rotates by a tiny 2–4° if it suits the icon, or nudges up 1–2 px. Use a short Quad/Back easing tween (~0.10–0.16 s). On mouse leave, tween precisely back to original scale, rotation, and position.
- Optional micro-animation: a single subtle 2-frame bounce or a slight shine sweep. Avoid perpetual spins, large elastic wobble, or many overlapping tweens.
- Pressed: button group scales to ~0.95 or icon nudges down while the bottom lip compresses. Restore hover state on release only if the pointer is still over the button; otherwise restore idle.
- Accessibility/mobile: hover is a desktop enhancement only. Buttons must still communicate their purpose and work on touch/gamepad. Never make an icon's hover animation the only feedback.

## Implementation safeguards
- Bind each button once with an attribute marker. Store and cancel the previous tween before starting a new tween on the same property.
- Handle `MouseEnter`, `MouseLeave`, `InputBegan`, `InputEnded`, and `Activated` appropriately. `Activated` is the cross-platform activation signal; avoid relying exclusively on `MouseButton1Down` for touch.
- Do not bind hover animation to floating `BillboardGui` world text. World labels have their own fixed-size visibility/fade behavior.
- If the icon is a child of the button, animate the icon's `UIScale` rather than scaling the whole button if the outline/body should stay fixed. For the user's button style, a subtle whole-button hover brightening plus icon-only scale is the preferred default.
