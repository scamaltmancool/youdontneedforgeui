# Canonical Roblox button styles

The user has two button systems. Select the style that matches the requested orientation. Do not mix measurements or label casing between them.

## Square portrait button (legacy variant)
Use when a 1:1 square button is requested. Sharp corners; ~2.5% black outline; green vertical gradient `#0F9A17` to `#06BB10`; dark green bottom lip `#06770B` at ~6% height. Glossy red basket icon in the upper ~65%, white handle, black sticker outline, no shadow. All-caps white Fredoka One/Lilita One-like label at bottom. Hover brightens and scales group to ~1.05–1.06; pressed scale ~0.95 and visually compress lip; disabled desaturates while retaining outline.

## Landscape button (current preferred variant)
Reference: `landscape-ui-style.md`. Use this for wide mobile-game buttons unless the user specifically asks for the square variant. Keep labels lowercase. Do not silently substitute rounded corners, drop shadows, glows, textures, or a modern flat UI.

## Shared Roblox construction rules
- Root is an `ImageButton` or `TextButton`, `AutoButtonColor = false`, sharp corners, no `UICorner`.
- Use `UIStroke` for the solid near-black outline. Keep the face and bottom lip as manually positioned layers.
- Use a `UIGradient` for a face made from Frames, or imported transparent artwork if exact gradients/illustrations need more fidelity.
- Text is a native `TextLabel` where wording needs to change at runtime. Set `TextScaled = false`, explicit `TextSize`, white fill, black `UIStroke`; position it manually.
- No `UIListLayout`, `UIGridLayout`, `UITableLayout`, or other layout objects inside a TextLabel or TextButton. A layout object is allowed on a parent container that arranges a collection of buttons/cards, only when that is actually useful.
- Do not duplicate a black border by stacking multiple strokes unless the reference explicitly requires it.

## Shared states
- Hover: brighten the face around 5%; icon artwork may scale to 1.05. On desktop, animate vector/image icon elements subtly. Avoid scaling the label independently in a way that changes readability.
- Press: reduce the lip to ~2–4 px as appropriate for the variant, shift face and content downward to match, or use a shared UIScale press effect.
- Disabled/sold-out: desaturate face/icon; retain strong black outlines and readable text.
- Mouse leave: restore the exact idle state. Avoid overlapping tweens that leave the button stuck enlarged. Touch devices must not require hover to understand or activate a button.
