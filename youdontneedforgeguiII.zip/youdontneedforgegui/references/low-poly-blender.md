# Low-poly, cartoony models: Blender first, Studio fallback

## Art direction

Make silhouettes readable from the normal Roblox camera distance. Favor large simple masses, bevel-free or lightly beveled edges, flat or softly shaded surfaces, a small number of saturated colors, and deliberate proportions. Use low-poly shading as an intentional style rather than making everything look unfinished. Avoid unnecessary tiny bolts, dense bevels, high-resolution textures, and hundreds of separate parts.

## Blender workflow (when available)

1. Start from primitives and establish silhouette before details. Use low-poly meshes, limited loop cuts, and restrained bevels.
2. Use flat shading for a toy-like style; add weighted normals/smooth shading selectively when a surface needs it.
3. Apply object transforms and name objects meaningfully. Keep pivot/origin at a useful placement point.
4. Use a small material palette; prefer Roblox materials/colors over dense texture maps where possible.
5. Reduce unnecessary geometry, apply modifiers deliberately, and check dimensions and scale before export.
6. Export a compatible FBX or another format currently supported by Roblox Studio's import pipeline. Import the model into Studio and verify orientation, scale, materials, pivots, collision fidelity, and mobile performance.
7. Separate collision geometry from visual mesh if a detailed silhouette creates poor collision. Use simple collision hulls for props that do not require precise interaction.

## Studio-only fallback

When Blender is unavailable, build models using a few anchored Parts, Wedges, corner wedges, cylinders, spheres, and simple MeshParts already available to the user. Use consistent proportions and palettes. Group related pieces into a Model, set a PrimaryPart when scripts need it, and use meaningful names. Do not approximate one prop with 100 tiny Parts if 5–12 simple parts would look good enough.

## Model budgets and behavior

- Prioritize fewer instances and simpler collision over tiny visual detail.
- Anchor decorative props that do not need physics.
- Keep decorative meshes free of scripts and unnecessary constraints.
- Set collision/query/touch properties intentionally, not reflexively on every part.
- Use streaming for large world regions; only use local decorative spawning for non-gameplay dressing.
- Never quietly replace user artwork with an unrelated generic model. Tell the user when a missing source mesh requires a Studio primitive approximation.
