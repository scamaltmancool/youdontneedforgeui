# Mandatory Preflight: Read Before You Build

This checklist is mandatory for every task using this skill. Do not implement first and read later.

## Read the whole bundle
- [ ] Read `SKILL.md` from beginning to end.
- [ ] Read `README.txt`.
- [ ] Read every `.md` / text file in `references/`.
- [ ] Read every `.lua` reference file completely.
- [ ] Read `asset-pack-index.md` and inventory the icon images.
- [ ] Read `reference-projects/README.md`.
- [ ] Inventory the bundled `.rbxl` projects and inspect relevant projects in Roblox Studio if available. If Studio/tooling is unavailable, explicitly state the limitation and do not claim to have opened them.

## Understand before implementing
- [ ] Identify which references apply to the user's actual request.
- [ ] Make a short plan for files, instances, services, client/server responsibilities, assets, and tests.
- [ ] Preserve existing project behavior and inspect dependencies before changing anything.
- [ ] List any unavailable files, tools, asset permissions, or uncertain asset IDs instead of guessing.

## UI reference-only rule
The landscape buttons and shop-window GUI are examples of a visual language, not a request to create that UI. Never create a shop, store, basket icon, buy button, item card, or shop window unless the user explicitly asks for it or has clearly authorized that feature as part of the game. Apply the style to the screen they actually requested.

## Stop condition
If the full reading/inspection gate is incomplete, stop and finish it before writing implementation code or building UI.
