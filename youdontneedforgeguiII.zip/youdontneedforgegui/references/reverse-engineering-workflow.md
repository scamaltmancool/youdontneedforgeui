# Auditing and adapting user-provided uncopylocked Roblox places

The bundle includes three `.rbxl` reference places in `reference-projects/`. Treat those projects as read-only sources until a change is explicitly requested. Their file names are sanitized for compatibility; the actual source files were supplied by the user.

## Safe, non-destructive audit

1. Duplicate the reference place to a separate working copy in Roblox Studio. Keep the source project untouched.
2. Before running Play mode, inspect unknown Scripts, LocalScripts, ModuleScripts, command-like modules, asset IDs, HTTP requests, remote events/functions, and require calls. Disable suspicious code in the working copy until understood; do not run unknown imported scripts blindly.
3. Make a map of the Explorer hierarchy: Workspace map sections, lighting and sky, StarterGui, StarterPlayer, ReplicatedStorage, ServerScriptService, ServerStorage, SoundService, remotes, modules, tags, and attributes.
4. Identify systems by behavior: main loop, round/spawn logic, shops, currency, inventory, checkpoints, movement, hazards, vehicles, progression, UI screens, camera, lighting, ambient sounds, and map boundaries.
5. Trace each important UI button from input to the client handler, through any remote, to server validation/state update, and back to UI feedback. Do not assume a client-side display is authoritative.
6. Document what exists before editing: name, location, purpose, dependencies, inputs/outputs, replication side, and any known unknowns.
7. Create a change plan for the target place. Port concepts or reimplement a system using the target game's conventions. Preserve its working architecture and remove only components proven unnecessary.
8. Test after each logical change. Keep a simple before/after log and a rollback point.

## Reusing models, map sections, UI, and lighting

- **Models:** check hierarchy, PrimaryPart/pivots, welds/constraints, collision/query/touch flags, scripts, textures, and instance count. Reuse only assets the user has the right to use. Retarget references by actual instance paths, never names guessed from screenshots.
- **UI:** inspect ScreenGui hierarchy, sizing/anchors, ZIndex, scaling, strokes, gradients, icon images, input handlers, and mobile behavior. Keep world labels separate from screen-space buttons.
- **Map:** record spawn points, paths, landmarks, occlusion, spawn safety, collision, streaming regions, and navigability. Do not copy an entire place if only one system is needed.
- **Lighting/sky:** inspect every effect under Lighting, ClockTime, brightness, ambient colors, Atmosphere, Sky, ColorCorrection, Bloom, and sun direction. Use owned/authorized assets and check performance.
- **Systems:** trace remotes and server authority; don't copy a shop or reward handler without reviewing exploitability and persistence.

## Adaptation boundaries

An uncopylocked project is a practical editable reference, but it does not mean every third-party mesh, image, audio, or embedded package has unrestricted redistribution rights. Keep references private unless rights are clear; do not strip permission checks, steal private/paid assets, bypass Roblox access controls, or claim copied work as original. Prefer original implementations and licensed assets. Never invent a source game's functionality from its filename alone; inspect the place first.

## Audit report template

- Reference project:
- Target project:
- Current hierarchy and systems:
- UI and interactions:
- Map and streaming:
- Lighting and atmosphere:
- Assets and possible licensing constraints:
- Risky/unreviewed scripts:
- Intended changes:
- Files/instances to edit:
- Validation and rollback plan:
