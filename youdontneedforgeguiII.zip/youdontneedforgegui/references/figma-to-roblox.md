# Figma-to-Roblox UI workflow

Use Figma as the design source when a real Figma connection is available. If no connected Figma tool exists in the current environment, create a Figma-ready component specification and transparent artwork exports; never claim you edited a live Figma document when you did not.

## 1. Build reusable components in Figma

- Create square 1:1 button components based on `ui-button-style.md`.
- Use component variants for Default, Hover, Pressed, and Disabled. Keep dimensions, outline width, icon scale, type size, and spacing consistent.
- Make a small token sheet for the palette, black outline, white label, gradients, font settings, spacing, and icon style.
- Keep icons isolated on transparent layers so they can be exported and replaced. If the text changes in-game, leave the text as live Roblox text rather than baking it into the bitmap.
- Design at a convenient base size (for example 256 x 256) and export important art at 2x or 3x for crisp edges.

## 2. Export assets

- Export icon art as transparent PNG when possible. Export backgrounds/face artwork separately if you want Roblox to animate the face/lip layers.
- SVG can be useful as an intermediate vector format, but don't assume Roblox UI will accept a raw SVG directly. Convert/import it into a Roblox-supported image format and verify the result in Studio.
- Use safe, descriptive file names such as `store-icon.png`, `settings-icon.png`, `button-green-face.png`.
- Check that the exported art has no unintended white matte, clipped black stroke, invisible padding, or excess transparent borders.

## 3. Import into Roblox Studio

1. Open the target place and Asset Manager / image import flow in Studio.
2. Import PNGs and wait for Roblox to process them. Use the resulting asset IDs; do not invent `rbxassetid://` numbers.
3. Apply the image IDs to `ImageLabel.Image` / `ImageButton.Image` or use them as a layer in a button component.
4. For public publishing, verify the uploader/account permissions and asset moderation status.
5. Keep dynamic labels as native `TextLabel`/`TextButton` objects where possible so they can update, scale for accessibility, and be localized.

## 4. Recreate states in Roblox

Figma variants are the design spec; Roblox code should control actual states. Use a local `UIScale` for the button group's hover/press behavior and TweenService for position/color/face-lip changes. Do not scale the text attached to world objects. The world-label system is proximity-based and should fade/disappear as the player leaves its range.

## 5. Acceptance checklist

- Aspect ratio and button dimensions stay square.
- Sharp square corners and solid black edge are preserved.
- Bottom lip remains visible and doesn't cover the label.
- Text is readable on desktop and mobile at actual in-game size.
- Hover, press, release, mouse leave, keyboard/gamepad selection, and touch all work.
- No unsupported export, fake asset ID, missing texture, or font substitution is hidden from the user.
