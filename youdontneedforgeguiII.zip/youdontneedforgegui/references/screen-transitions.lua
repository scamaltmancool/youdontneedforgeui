-- ModuleScript example named ScreenTransitions under ReplicatedStorage or inside the UI.
-- Pass a CanvasGroup that wraps the panel contents. Use one CanvasGroup per animated panel.

local TweenService = game:GetService("TweenService")
local ScreenTransitions = {}
local activeTweens = {}
local SHOW_INFO = TweenInfo.new(0.22, Enum.EasingStyle.Quint, Enum.EasingDirection.Out)
local HIDE_INFO = TweenInfo.new(0.16, Enum.EasingStyle.Quad, Enum.EasingDirection.In)

local function play(group: CanvasGroup, info: TweenInfo, goal)
    local previous = activeTweens[group]
    if previous then
        previous:Cancel()
    end
    local tween = TweenService:Create(group, info, goal)
    activeTweens[group] = tween
    tween:Play()
    tween.Completed:Once(function()
        if activeTweens[group] == tween then
            activeTweens[group] = nil
        end
    end)
    return tween
end

function ScreenTransitions.Show(group: CanvasGroup, offsetPixels: number?)
    local offset = offsetPixels or 16
    local targetPosition = group.Position
    group.Visible = true
    group.GroupTransparency = 1
    group.Position = UDim2.new(
        targetPosition.X.Scale, targetPosition.X.Offset,
        targetPosition.Y.Scale, targetPosition.Y.Offset + offset
    )
    play(group, SHOW_INFO, { GroupTransparency = 0, Position = targetPosition })
end

function ScreenTransitions.Hide(group: CanvasGroup, offsetPixels: number?)
    local offset = offsetPixels or 10
    local targetPosition = group.Position
    local tween = play(group, HIDE_INFO, {
        GroupTransparency = 1,
        Position = UDim2.new(
            targetPosition.X.Scale, targetPosition.X.Offset,
            targetPosition.Y.Scale, targetPosition.Y.Offset + offset
        ),
    })
    tween.Completed:Once(function(state)
        if state == Enum.PlaybackState.Completed and group.Parent and group.GroupTransparency >= 0.99 then
            group.Visible = false
            group.Position = targetPosition
        end
    end)
end

return ScreenTransitions
