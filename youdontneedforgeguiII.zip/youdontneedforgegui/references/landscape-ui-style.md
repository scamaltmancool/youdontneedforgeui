# Landscape UI style — canonical current specification

This is the authoritative reference for the user's landscape-oriented button and shop-window system. Treat supplied pixel dimensions as reference values; scale responsively as a group for different viewport sizes without changing the design ratios. Keep 90-degree corners, solid near-black outlines, saturated gradients, dark bottom lips, bold rounded lettering, and glossy cartoon icons. No drop shadows, glow, or noisy texture unless requested by the user.

## Landscape buttons

Base geometry: total height 86 px including outline. Wide width 365 px; small width 178 px. Only width varies between button sizes. Use a 6 px `#080908` outline on all sides, sharp square corners. Face height 61 px with vertical gradient `#3EAF24` top → `#44CC2E` middle → `#47D832` bottom. Bottom lip is solid `#158B15`, 13 px high, inside the outline. No shadow, glow, inner highlight, or texture in the clean base style.

Text: lowercase only, e.g. `shop`, `open`; ultra-bold rounded bubbly sans like Fredoka One/Lilita One; about 36 px at reference size; white `#FFFFFF` fill and black `#080908` stroke about 5 px, rounded joins. Vertically centered over the face and above the lip. No text shadow/gradient.

Icon: glossy cartoony red basket with white/light-gray handle; pink-red upper shading, deeper crimson lower shading, dark maroon interior. Slight tilt ~8–10°. Black sticker outline ~5 px. Icon height around 65–70% of total button height, placed on the left with ~6 px padding; allow slight overlap over the top/left outer outline as specified. Icon and label should be grouped/positioned together intentionally.

Layouts:
1. Wide icon + label (`shop`): icon on left, label immediately to the right with 6–8 px gap; leave remaining face empty.
2. Small icon + label (`open`): same pattern, sized to fit the 178 px width; text uses remaining space and must not clip.
3. Small label only (`open`): no icon; label centered on the face.

States:
- Hover: brighten the face gradient by about 5%; icon may animate independently and scale up to 1.05, then return to base on leave.
- Press: shrink lip from 13 px to ~4 px; move face, icon, and text down by 9 px so the layers still align. Avoid shifting the outer outline itself unless the mockup explicitly does so.
- Disabled: desaturate greens to gray while retaining black outlines and readable white label.

## Shop window / menu

Reference canvas approximately 620 × 520 px. Dark gray background `#1E1E1E`. Every shape has a solid black `#000000` outline around 5 px and square corners. Panels use vertical gradients (darker top → lighter bottom) and a darker flat bottom lip. Text is lowercase, bold rounded bubbly sans, white with black stroke about 15% of font size; no shadow or gradient. Icons use glossy cartoon shading and black sticker outlines, slightly tilted ~8–10°.

Header: x/y reference starts around y=13 and runs to ~85. Header is wider than the body by about 50 px on each side. Olive gradient `#8B9318` → `#CED664` → `#F7FE91`, black 5 px outline, dark olive lip about 8 px visible below/at the sides. Red basket icon ~60 px at left with ~10 px padding, then `shop` title ~40 px.

Close button: about 66 × 85 px, overlaps header's right end. Red gradient `#A02121` → `#BF3838` → `#DE4E4E`; black 5 px outline, dark red 8 px lip, white `X` about 45 px with thick black stroke. (Interpret the source's malformed middle color `#BF38 38` as `#BF3838`.)

Body panel: about 520 × 445 px, centered under header; body top overlaps header bottom enough to preserve the layered lip/outline read. Reference placement x=144→664, y=85→526. Black 5 px outline; gradient `#710808` → `#881C1C` → `#9C2E2E` → `#AF3F3F` → `#C45151`; dark lip `#611E1E`, 23 px high; inner padding ~16 px.

Section title: `todays picks`, ~30 px, left aligned, about 16 px from body's left inner edge and 20 px from top.

Item card: ~192 × 198 px, top-left inside body, 12 px from body inner left. Black 5 px outline; gradient `#620A0A` → `#811313` → `#A31F1F` → `#CB2A2A`. Basket icon ~130 px wide, centered and slightly above center, tilt ~8°, sticker outline. Label `fruit`, ~30 px, centered near bottom and slightly overlapping the icon. Leave about 18 px between section title and card top.

Buy button: ~149 × 57 px, centered beneath card and partly hidden behind the card bottom edge to look tucked underneath. Green gradient `#387510` → `#3F9E1D` → `#44BF27`; dark green lip `#375B0A`, ~8 px; black 5 px outline; `buy` ~22 px centered on face above lip.

Window animation: open from scale 0.90 to 1.0 with a quick restrained bounce and fade the background in; close by reversing/fading out. Use `TweenService`, cancel/replace conflicting tweens, and restore visibility/interactivity correctly at completion. Do not animate every descendant separately if a parent `CanvasGroup` can do it cleanly.

Card states: hover scale to ~1.03, then return to 1.0 on leave. Sold-out/disabled cards are desaturated. Buy/close hover brightens face ~5%; pressed lip compresses to ~2 px and the face/content shift together.

Responsive rule: keep these proportions and relative placements, but don't hardcode the reference pixels as a universal screen size. Use a root `UIScale` or carefully sized constraints and test at the target landscape resolutions. Avoid layouts inside text objects; use manual positioning for label/icon pairs. A parent grid can arrange repeated item cards when there are multiple cards.
