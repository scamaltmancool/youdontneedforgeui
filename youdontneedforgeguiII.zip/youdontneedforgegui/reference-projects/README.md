# User-supplied uncopylocked reference projects

- `steal_from_template.rbxl` — source file uploaded as `- Steal From Template.rbxl`.
- `escape_tsunami_for_car.rbxl` — source file uploaded as `Escape Tsunami for Car.rbxl`.
- `my_lucky_block_template.rbxl` — source file uploaded as `My Lucky Block Template.rbxl`.

These are bundled as source references, not pre-audited or modified versions. Open a copy in Roblox Studio and follow `../references/reverse-engineering-workflow.md` before execution or adaptation. This package does not claim the original place files or embedded third-party assets are owned by the skill author.
